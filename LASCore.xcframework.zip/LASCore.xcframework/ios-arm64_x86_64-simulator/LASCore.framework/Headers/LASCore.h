//
//  LASCore.h
//  LASCore
//
//  Created by KlevinC on 05/03/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for LASCore.
FOUNDATION_EXPORT double LASCoreVersionNumber;

//! Project version string for LASCore.
FOUNDATION_EXPORT const unsigned char LASCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LASCore/PublicHeader.h>


